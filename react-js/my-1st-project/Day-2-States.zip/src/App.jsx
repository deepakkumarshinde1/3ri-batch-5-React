import { useState } from "react";

const App = () => {
  // hooks (v16.8) ==> function/methods ==> to perform complex operation in vDom
  const [text, setText] = useState("-"); // declaration

  const changeText = (event) => {
    if (event.keyCode === 13) {
      setText(event.target.value);
    }
  };

  return (
    <>
      <input type="text" onKeyUp={changeText} />
      {/* <button
        onClick={changeText}
        className="btn btn-outline-primary rounded-0 btn-sm"
      >
        Change Text
      </button> */}
      <h1>Here Your Text:: {text}</h1>
    </>
  );
};

export default App;
