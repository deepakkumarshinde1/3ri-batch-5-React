import { createSlice } from "@reduxjs/toolkit";

const ProductSlice = createSlice({
  name: "ProductSlice",
  initialState: {
    category: [],
  },
  reducers: {
    getCategoryList: (state, action) => {
      let { payload } = action;
      state.category = payload;
    },
  },
});

export const { getCategoryList } = ProductSlice.actions;
export default ProductSlice;
