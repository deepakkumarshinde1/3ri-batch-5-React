import axios from "axios";
export const config = {
  GET: axios.get,
  POST: axios.post,
  PUT: axios.put,
  DELETE: axios.delete,
  BASE_URL: "http://localhost:3003",
};
