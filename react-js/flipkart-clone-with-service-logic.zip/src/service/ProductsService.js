import { config } from "./config";
let { GET, BASE_URL } = config;

export const getCategory = async () => {
  try {
    let { data } = await GET(BASE_URL + "/categories");
    return data;
  } catch (error) {
    alert("Server Error , Check Console");
    console.log(error);
    return [];
  }
};
